package com.geproject.Geproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class GeprojectApplication{
	public static void main(String[] args) {
		SpringApplication.run(GeprojectApplication.class, args);
	}
}
