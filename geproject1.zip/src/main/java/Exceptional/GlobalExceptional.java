package Exceptional;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice

public class GlobalExceptional{
	
	
	/*
	 * //Specific- exception
	 * 
	 * @ExceptionHandler(ResourceNotFoundException.class) public ResponseEntity<?>
	 * handleResourceNotFoundException (ResourceNotFoundException
	 * exception,WebRequest request){ ExceptionalHandler exceptionalHandler = new
	 * ExceptionalHandler (new
	 * Date(),exception.getMessage(),request.getDescription(false)); return new
	 * ResponseEntity(exceptionalHandler,HttpStatus.NOT_FOUND); }
	 */
	
	
	//API- exception
	@ExceptionHandler(APIException.class)
		public ResponseEntity<?> handleAPIException
		(APIException exception,WebRequest request){
			ExceptionalHandler exceptionalHandler = new ExceptionalHandler
					(new Date(),exception.getMessage(),request.getDescription(false));
			return  new ResponseEntity(exceptionalHandler,HttpStatus.NOT_FOUND);
		}
	
	
	//Global Exception
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleGlobalException(Exception exception,WebRequest request){
	ExceptionalHandler exceptionalHandler = new ExceptionalHandler
				(new Date(),exception.getMessage(),request.getDescription(false));
		return  new ResponseEntity(exceptionalHandler,HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
