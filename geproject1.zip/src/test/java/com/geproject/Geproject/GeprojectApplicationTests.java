package com.geproject.Geproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
